package Metier.Cartes;

public enum Type_Cartes {
    Carte_Arme, Carte_Suspect, Carte_Lieu;
}
