package Metier.Cartes.Lieux;

public enum Type_Lieux {
    Salle_a_manger, Salon,  Cuisine, Hall, Chambre, Bureau, Bibliotheque;
}
