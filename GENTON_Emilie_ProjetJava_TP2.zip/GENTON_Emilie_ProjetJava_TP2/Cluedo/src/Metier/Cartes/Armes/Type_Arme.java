package Metier.Cartes.Armes;

public enum Type_Arme {
    Poignard, Corde, Chandelier, Revolver, CleAnglaise, Matraque;
}
