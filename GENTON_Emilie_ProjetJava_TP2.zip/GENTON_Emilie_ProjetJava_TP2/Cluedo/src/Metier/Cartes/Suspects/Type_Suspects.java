package Metier.Cartes.Suspects;

public enum Type_Suspects {
    Rose, Moutarde, Violet, Leblanc, Olive, Pervenche;
}
