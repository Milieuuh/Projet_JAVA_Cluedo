package Metier.Cases;

public enum Type_Case {
    Salle_a_manger, Salon,  Cuisine, Hall, Chambre, Bureau, Bibliotheque, Classique; //Type Classique étant une case vierge
}
